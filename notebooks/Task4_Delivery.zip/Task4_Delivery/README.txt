TASK 4 - INSIGHTS & ANOMALIES (Customer Voice Radar)

1. Task4_Insights.ipynb
   Colab notebook with all code, split into 5 parts (one per team member).

2. Task4_PowerBI.xlsx
   Final combined output for the Power BI dashboard (4 sheets):
   Anomalies, Anomaly_Summary, Customer_Health, Late_By_City.

3. task4_1_order_anomalies.csv
   Order and price anomalies (Part 1).

4. task4_2_delivery_review_anomalies.csv
   Delivery, review and customer anomalies, built with SQL (Part 2).

5. task4_3_customer_health_score.csv
   Customer Health Score (0-100) per customer (Part 3).

Inputs used: Cleaned_Data from the data engineering delivery + 07_Reviews_Analyzed.csv.
