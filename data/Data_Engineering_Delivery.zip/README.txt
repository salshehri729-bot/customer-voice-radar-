
DATA ENGINEERING PROJECT - FINAL DELIVERY

1. Cleaned_Merged_Data.csv
   Main merged dataset at order-item level.

2. Cleaned_Inventory.csv
   Inventory dataset kept separately.

3. Cleaning_Log.csv
   Documentation of cleaning actions.

4. Original_Data/
   Original source files preserved without modification.

5. Cleaned_Data/
   Cleaned individual datasets.

6. Quarantined_Data/
   Records isolated for further verification.

Note:
Missing customer IDs and missing delivery days were
preserved where reliable replacement values were unavailable.
Inventory with missing stock values was retained.
